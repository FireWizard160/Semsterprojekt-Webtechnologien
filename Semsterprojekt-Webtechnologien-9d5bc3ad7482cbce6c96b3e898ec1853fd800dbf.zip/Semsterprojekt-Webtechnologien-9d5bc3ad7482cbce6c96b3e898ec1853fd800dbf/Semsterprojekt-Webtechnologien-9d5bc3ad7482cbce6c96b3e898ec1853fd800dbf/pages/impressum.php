<!DOCTYPE html>
<html lang="en">
<head>

    <title>Hilfe</title>

</head>
<body>


<h2>Hotelverwaltung</h2> <br>

<div class="container-fluid">
<div class="row">

    <div class="col-md-6 d-flex justify-content-center">


        <div class="card" style="width: 18rem;" id="profilepictures">
            <img src="../lukas_mayer.gif" class="card-img-top" alt="Lukas Mayer">

            <div class="card-body" id="profilepicturesbody">

                <h5 class="card-title">Lukas Mayer</h5>


            </div>
        </div>

    </div>
    <div class="col-md-6 d-flex justify-content-center">
        <div class="card" style="width: 18rem;" id="profilepictures">
            <img src="../wendelin.gif" class="card-img-top" alt="Wendelin Windhager">

            <div class="card-body" id="profilepicturesbody">

                <h5 class="card-title">Wendelin Windhager</h5>


            </div>
        </div>
    </div>
</div>

    <h2 style=text-align:center>Das HoteLouvre!</h2>

    <div class="container" id="impressum">

       
            <address>
            PLZ: 95380 Paris <br>
            Adresse: 75001 Paris / France <br>
            Hotel: HoteLouvre<br>
            Tel: +33 5965698<br>
            E-Mail: email@server.domain<br>
            UID-Nr. FRU12837412<br>
            Mitglied der WKÖ<br>
            Berufsrecht: <a
                    href="https://www.ris.bka.gv.at/GeltendeFassung.wxe?Abfrage=Bundesnormen&Gesetzesnummer=10007517">Gewerbeordnung</a><br>
            
            </address>
            <p>
                Paris
            Meisterbetrieb, Meisterprüfung abgelegt in Frankreich. 
            Verbraucher haben die Möglichkeit, 
            Beschwerden an die OnlineStreitbeilegungsplattform der EU zu richten:
            <a href="http://ec.europa.eu/odr.">Europa</a> 
            Sie können allfällige Beschwerde auch an die
            oben angegebene E-Mail-Adresse richten </p>
            <br><br>

    </div>


</body>
</html>

