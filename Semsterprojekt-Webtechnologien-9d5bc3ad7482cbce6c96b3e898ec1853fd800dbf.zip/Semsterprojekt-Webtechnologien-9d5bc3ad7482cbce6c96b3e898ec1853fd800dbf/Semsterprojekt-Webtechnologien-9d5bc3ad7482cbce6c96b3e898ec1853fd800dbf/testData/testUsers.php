<?php
function getTestUsers()
{
    return array(
        array("username" => "user1@example.com", "password" => "passwort1"),
        array("username" => "user2@example.com", "password" => "passwort2"),
        array("username" => "user3@example.com", "password" => "passwort3"),
        array("username" => "user4@example.com", "password" => "passwort4"),
        array("username" => "user5@example.com", "password" => "passwort5"),
        array("username" => "user6@example.com", "password" => "passwort6"),
        array("username" => "user7@example.com", "password" => "passwort7"),
        array("username" => "user8@example.com", "password" => "passwort8"),
        array("username" => "user9@example.com", "password" => "passwort9"),
        array("username" => "user10@example.com", "password" => "passwort10"),
        array("username" => "user11@example.com", "password" => "passwort11"),
        array("username" => "user12@example.com", "password" => "passwort12"),
        array("username" => "user13@example.com", "password" => "passwort13"),
        array("username" => "user14@example.com", "password" => "passwort14"),
        array("username" => "user15@example.com", "password" => "passwort15"),
        array("username" => "user16@example.com", "password" => "passwort16"),
        array("username" => "user17@example.com", "password" => "passwort17"),
        array("username" => "user18@example.com", "password" => "passwort18"),
        array("username" => "user19@example.com", "password" => "passwort19"),
        array("username" => "user20@example.com", "password" => "passwort20")
    );
}