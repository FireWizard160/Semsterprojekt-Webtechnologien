<?php
    // Session wird geschlossen und man wird zur Anmeldung weitergeleitet
    session_destroy();
    $_GET['page'] = "anmeldung";
    header('Refresh: 1; URL =index.php?page=anmeldung');
?>
