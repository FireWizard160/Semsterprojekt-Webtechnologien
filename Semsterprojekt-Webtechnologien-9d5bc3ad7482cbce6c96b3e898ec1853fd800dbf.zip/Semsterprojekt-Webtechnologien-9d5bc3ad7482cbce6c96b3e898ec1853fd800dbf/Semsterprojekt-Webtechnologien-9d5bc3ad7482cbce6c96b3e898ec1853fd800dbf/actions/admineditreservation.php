<?php
include 'db/db_conncect.php';

$db = getDBConnection();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Updaten der sichtbaren Reservierungen, auch um neue zu sehen
    $reservationID = $_POST['reservationID'];
    $userID = $_POST['userID'];
    $status = $_POST['status'];

    // den Reservierungen wird der korrekte Status laut DB gegeben
    if ($status === 'neu') {
        $statusValue = 0;
    } elseif ($status === 'bestaetigt') {
        $statusValue = 1;
    } elseif ($status === 'storniert') {
        $statusValue = 2;
    } else {
        echo "Ungültiger Status übergeben.";

        exit(); 
    }

    $updateReservationSQL = "UPDATE reservations 
                             SET reservationStatus = '$statusValue'
                             WHERE reservationID = '$reservationID'";

    if ($db->query($updateReservationSQL) === TRUE) {
        echo "Reservierung erfolgreich aktualisiert.";
        $_GET['page'] = "reservationverwaltung";
    } else {
        echo "Fehler beim Aktualisieren der Reservierung: " . $db->error;
    }
}

$db->close();
?>
